import datetime #Built In Library bukan Eksternal
import os #Built In Library bukan Eksternal
import json #Built In Library bukan Eksternal
import csv #Built In Library bukan Eksternal
import textwrap #Built In Library bukan Eksternal
import time #Built In Library bukan Eksternal

## ------ Start Warna Terminal ------ ##
RESET = "\033[0m"
BOLD = "\033[1m"
UNDERLINE = "\033[4m"
GREEN = "\033[92m"
YELLOW = "\033[33m"
BYELLOW = "\033[93m"
RED = "\033[91m" 
BLUE = "\033[34m"
CYAN = "\033[36m"
BCYAN = "\033[96m"

YELLOW_BG = "\033[43m" 

## ------ End Warna Terminal ------ ##

## -------- AWAL BAGIAN KONFIGURASI -------- ##

CONFIG_JSON_USER = 'user.json'
LOG_BELAJAR = 'log_belajar.json'

def inputString(msg):
  while True:
    try:
      inputUser = input(msg)
      bersihInputUser = inputUser.strip()
      if len(bersihInputUser) == 0:
        raise ValueError
      
      return inputUser
      
    except ValueError:
      print(f"{RED}{BOLD}Inputan Tidak Boleh Kosong!{RESET}")

def configUser():
  namaLengkap = input("Masukkan Nama Lengkapmu: ")
  namaPanggilan = input("Kamu Suka Dipanggil apa (Nama Panggilan): ")
  kelas = int(input("Masukkan Kelasmu (Contoh: 10): "))
  mataPelajaranInput = inputString("Masukkan Mata Pelajaranmu (Pisahkan menggunakan koma ','): ")
  mataPelajaranKotor = mataPelajaranInput.split(',')
  mataPelajaran = []
  for mapel in mataPelajaranKotor:
    mapelBersih = mapel.strip()
    if mapelBersih:
      mataPelajaran.append(mapelBersih)
      
  CONFIG_USER = {
    'nama_lengkap': namaLengkap,
    'nama_panggilan': namaPanggilan,
    'kelas': kelas,
    'mata_pelajaran': mataPelajaran,
    'point': 0,
  }

  return CONFIG_USER

def updateUser(dataUser):
  if not os.path.exists(CONFIG_JSON_USER):
    print(f"{RED}Error: File {CONFIG_JSON_USER} tidak ditemukan!")
    CONFIG_USER = configUser()
    return CONFIG_USER
  
  try:
    with open(CONFIG_JSON_USER, 'w', encoding="utf-8") as jsonfile:
      json.dump(dataUser, jsonfile, indent=4)

  except Exception as e:
    print(f"{RED}{BOLD}ERROR saat menimpa/menyimpan file JSON: {e}{RESET}")

def loadUser():
  if not os.path.exists(CONFIG_JSON_USER):
    print(f"{RED}Error: File {CONFIG_JSON_USER} tidak ditemukan!")
    CONFIG_USER = configUser()
    return CONFIG_USER
  
  try:
    with open(CONFIG_JSON_USER, 'r', encoding="utf-8") as jsonfile:
      CONFIG_USER = json.load(jsonfile)
      return CONFIG_USER
    
  except json.JSONDecodeError as e:
        print(f"{RED}ERROR: Kesalahan format JSON dalam file. Detail: {e}{RESET}")
        return None
        
  except Exception as e:
        print(f"{RED}ERROR: Gagal membaca file. Detail: {e}{RESET}")
        return None
  
def deteksiWaktuHari():
  waktuSekarang = datetime.datetime.now()
  jam = waktuSekarang.hour

  if 5 <= jam < 11:
    return "Pagi"
  elif 11 <= jam < 15:
    return 'Siang'
  elif 15<= jam < 18:
    return 'Sore'
  else:
    return 'Malam'
  
def pause_and_continue(message="Tekan ENTER untuk melanjutkan..."):
    input(f"\n\n{YELLOW_BG}{message}{RESET}")

def inputAngkaAman(msg, tanpaNegatif, batasMaksimum=0, batasMinimum=0):
  while True:
    try:
      angka = int(input(msg))

      if tanpaNegatif:
        if angka < 0:
          raise Exception("Dilarang Memasukkan Angka Negatif!")
        
      if ((batasMaksimum != 0 or batasMinimum != 0) and (angka > batasMaksimum or batasMinimum > angka)):
        raise Exception(f"Masukkan Angka Di antara {batasMinimum} s.d. {batasMaksimum}")
      return angka
        
    except ValueError:
      print(f"{BOLD}{RED}Tolong Masukkan Angka!{RESET}")

    except Exception as e:
      print(f"{BOLD}{RED}Error: {e}{RESET}")

def levelPrioritas(tanggalDeadline, tingkatKesulitan):
  tanggalPemberian = datetime.datetime.now()
  tahunSisa = tanggalDeadline.year - tanggalPemberian.year
  bulanSisa = tanggalDeadline.month - tanggalPemberian.month
  hariSisa = tanggalDeadline.day - tanggalPemberian.day

  hariSisaTotal = tahunSisa * 365 + bulanSisa * 30 + hariSisa

  urgency = 0

  if hariSisaTotal <= 0:
    urgency = 5
  elif hariSisaTotal <= 1:
    urgency = 4
  elif hariSisaTotal <= 3:
    urgency = 3
  elif hariSisaTotal <= 5:
    urgency = 2 
  else:
    urgency = 1

  tingkatPrioritas = urgency * 3 + tingkatKesulitan

  if tingkatPrioritas <= 7:
    levelPrioritas = "Rendah"
  elif tingkatPrioritas <= 11:
    levelPrioritas = "Sedang"
  elif tingkatPrioritas <= 15:
    levelPrioritas = "Tinggi"
  else:
    levelPrioritas = "Sangat Kritis"

  return levelPrioritas

def loadTugas(file):
  data = []
  try:
    with open(file, 'r', newline='', encoding="utf-8") as csvfile:
      reader = csv.DictReader(csvfile)
      fieldnames = reader.fieldnames
      for row in reader:
        data.append(row)
      
      return data
    
  except FileNotFoundError:
    raise Exception("Data pada bulan atau tahun tidak ditemukan.")
    return 0

  except Exception as e:
    print(f"{RED}{BOLD}Error: {e}{RESET}")
    return 0

def loadTugasTabel(file, tipeKondisi = None, syarat = None):

  if not os.path.exists(file):
    print(f"{RED}{BOLD}Tidak ditemukan file dan tugas pada bulan dan tahun tersebut!{RESET}")
    return 0
  
  LEBAR_TEKS_MAKS = 20
  PADDING = 2

  dictTipeKondisi = {
    'mp': "mata_pelajaran", 
    'tpem': 'tanggal_pemberian', 
    'tpeng': 'tanggal_pengumpulan', 
    'lp': 'level_prioritas',
    'kt': 'kondisi_tugas'
  }

  if not tipeKondisi:
    kondisiSpesial = None
  else :
    kondisiSpesial = dictTipeKondisi[tipeKondisi]
  
  fieldnames = []
  dataTugas = []
  try:
    with open(file, 'r', newline='', encoding='utf-8') as csvfile:
      reader = csv.DictReader(csvfile)
      fieldnames = reader.fieldnames
      dataTugas = list(reader)

    if not dataTugas:
      print(f"{RED}{BOLD}Tidak ada tugas pada bulan dan tahun tersebut{RESET}")  
    

    lebarKolom = {}

    for name in fieldnames:
      if name.lower() in ['deskripsi']:
        lebarKolom[name] = LEBAR_TEKS_MAKS
      else:
        maxLen = len(name)
        for row in dataTugas:
          if len(row[name]) > maxLen:
            maxLen = len(row[name])

        lebarKolom[name] = maxLen

      lebarKolom[name] += PADDING

    def cetakPembatas():
      line = "+"
      for w in lebarKolom.values():
        line += "-" * w + '+'
      print(line)

    cetakPembatas()
    headerLine = '|'
    for name in fieldnames:
      headerLine += name.center(lebarKolom[name]) + '|'

    print(headerLine)
    cetakPembatas()

    for row in dataTugas:
      potonganTeks = {name: [] for name in fieldnames}
      tinggiBarisMax = 1
      
      if (tipeKondisi != None) and (row[kondisiSpesial] != syarat):
        continue

      for name in fieldnames:
        cellValue = row[name]

        if name.lower() in ['deskripsi']:
          potongan = textwrap.wrap(cellValue, width=LEBAR_TEKS_MAKS)
        else:
          potongan = [cellValue]

        potonganTeks[name] = potongan

        if len(potongan) > tinggiBarisMax:
          tinggiBarisMax = len(potongan)

    
      for j in range(tinggiBarisMax):
        dataLine = '|'
        for name in fieldnames:
          if j < len(potonganTeks[name]):
            cellContent = potonganTeks[name][j]
          else:
            cellContent = ""
        
          dataLine += cellContent.ljust(lebarKolom[name]) + '|'
      
        print(dataLine)
  
      cetakPembatas()

  except Exception as e:
    print(f"{RED}{BOLD}Error tak terduga saat memproses tabel: {e}{RESET}")

def updateCSVPrioritas(filePath):
  dataDiperbarui = []

  try:
    with open(filePath,'r', newline ='', encoding ='utf-8') as infile:
      reader = csv.DictReader(infile)
      fieldnames = reader.fieldnames

      for row in reader:
        tanggalPemberian = datetime.datetime.strptime(row['tanggal_pemberian'], "%d/%m/%Y")
        tanggalPengumpulan = datetime.datetime.strptime(row['tanggal_pengumpulan'], "%d/%m/%Y")
        row['level_prioritas'] = levelPrioritas(tanggalPemberian, tanggalPengumpulan, int(row.get('tingkat_kesulitan')))
        dataDiperbarui.append(row)

    with open(filePath, 'w', newline='', encoding='utf-8') as outfile:
      writer = csv.DictWriter(outfile, fieldnames)

      writer.writeheader()
      writer.writerows(dataDiperbarui)

  except Exception as e:
    print(f"{RED}{BOLD}Error: {e}{RESET}")

def loadLastStudyDate():
  if not os.path.exists(LOG_BELAJAR):
    return None
  try:
    with open(LOG_BELAJAR, 'r') as jsonfile:
      data = json.load(jsonfile)
      return data.get('last_study_date')
  except (FileNotFoundError, json.JSONDecodeError):
    return None

def updateLastStudyDate():
  today = datetime.datetime.now().strftime('%d/%m/%Y')
  data = {'last_study_date': today}
  with open(LOG_BELAJAR, 'w') as f:
    json.dump(data, f)

# -------- AKHIR BAGIAN KONFIGURASI -------- ##

## -------- AWAL BAGIAN MENU ----------- ##

def ucapanSelamatDatang(newUser):
  def formatLine(isi): 
    centeredText = isi.center(LEBAR_BINGKAI_TOTAL)
    return f"║{BOLD}{GREEN}{centeredText}{RESET}║"
  
  def formatLineMerah(isi):
    centeredText = isi.center(LEBAR_BINGKAI_TOTAL)
    return f"║{BOLD}{RED}{centeredText}{RESET}║"
  if (newUser):
    pesanPertanyaan = "Tolong Jawab Pertanyaan untuk Penggunaan Aplikasi yang Lebih Baik"
    pesan2 = "Sepertinya Anda Pengguna Baru"
    pesan1 = "Kelola Tugas Anda lebih teratur"

    judul = "QEE: PENCATAT TUGAS SEKOLAH"

    panjangTeks = [len(judul), len(pesanPertanyaan), len(pesan1), len(pesan2)]
    panjangMaks = max(panjangTeks)
    PADDING = 12
    LEBAR_KONTEN = panjangMaks + PADDING

    LEBAR_BINGKAI_TOTAL = LEBAR_KONTEN + 2
    GARIS_PENUH = "═" *LEBAR_BINGKAI_TOTAL
  
    print(f"╔{GARIS_PENUH}╗")
    print(formatLine(""))

    print(formatLine(judul))
    print(formatLine(''))

    print(formatLine(pesan1))
    print(formatLine(""))

    print(formatLine(pesan2))
    print(formatLine(""))

    print(formatLine(pesanPertanyaan))
    print(formatLine(""))

    print(f"╚{GARIS_PENUH}╝")

    return 0
  
  dataUser = loadUser()
  waktuUser = deteksiWaktuHari()
  today = datetime.datetime.now().strftime("%d/%m/%Y")
  lastStudyDate = loadLastStudyDate()
  
  judul = "QEE: PENCATAT TUGAS SEKOLAH"
  isi = "Kelola Tugas Anda lebih teratur"
  pesanSelamat = f"Selamat {waktuUser} {dataUser['nama_panggilan']}"
  isiNext = ""

  if lastStudyDate != today:
    isiNext = f"Hei {dataUser['nama_panggilan']}, hari ini kamu belum belajar!"

  panjangTeks = [len(judul), len(pesanSelamat), len(isiNext), len(isi)]
  panjangMaks = max(panjangTeks)
  PADDING = 12
  LEBAR_KONTEN = panjangMaks + PADDING

  LEBAR_BINGKAI_TOTAL = LEBAR_KONTEN + 2
  GARIS_PENUH = "═" *LEBAR_BINGKAI_TOTAL
  
  print(f"╔{GARIS_PENUH}╗")
  print(formatLine(""))

  print(formatLine(judul))
  print(formatLine(''))

  print(formatLine(isi))
  print(formatLine(""))
  
  print(formatLine(pesanSelamat))
  print(formatLine(""))

  if isiNext != "":
    print(formatLineMerah(isiNext))
    print(formatLine(""))
  print(f"╚{GARIS_PENUH}╝")

def clearScreen():
  if os.name =='nt':
    os.system('cls')
  else:
    os.system('clear')

def startNew():
  ucapanSelamatDatang(True)
  CONFIG_USER = configUser()
  with open(CONFIG_JSON_USER, 'w', encoding='utf-8') as jsonfile:
    json.dump(CONFIG_USER, jsonfile, indent=2)

  print("-" * 50)
  print(f"## DATA PENGGUNA: {CONFIG_USER['nama_panggilan']} ##".center(50)) # center() untuk perataan
  print("-" * 50)

  print(f"Nama Lengkap    : {BOLD}{CONFIG_USER['nama_lengkap']}{RESET}")
  print(f"Nama Panggilan  : {BOLD}{CONFIG_USER['nama_panggilan']}{RESET}")
  print(f"Kelas           : {BOLD}{CONFIG_USER['kelas']}{RESET}")
  print("Mata Pelajaran :")
  listMataPelajaran = CONFIG_USER["mata_pelajaran"]
  for i in range(len(listMataPelajaran)):
    print(f"{i+1}. {BOLD}{listMataPelajaran[i]}{RESET}")
  pause_and_continue()
  clearScreen()

def startOld():
  ucapanSelamatDatang(False)

def pesanEndApp():
  judul = "Terima Kasih Sudah Menggunakan Aplikasi Ini"
  pesan1 = "Semoga Tugas Anda Terselesaikan Dengan Baik"
  pesan2 = "Sampai Jumpa Lagi!"

  panjangTeks = [len(judul), len(pesan1), len(pesan2)]
  panjangMaks = max(panjangTeks)
  PADDING = 12
  LEBAR_KONTEN = panjangMaks + PADDING

  LEBAR_BINGKAI_TOTAL = LEBAR_KONTEN + 2
  GARIS_PENUH = "═" *LEBAR_BINGKAI_TOTAL

  def formatLine(isi): 
    centeredText = isi.center(LEBAR_BINGKAI_TOTAL)
    return f"║{BOLD}{GREEN}{centeredText}{RESET}║"
  
  print(f"╔{GARIS_PENUH}╗")
  print(formatLine(""))

  print(formatLine(judul))
  print(formatLine(''))

  print(formatLine(pesan1))
  print(formatLine(""))

  print(formatLine(pesan2))
  print(formatLine(""))

  print(f"╚{GARIS_PENUH}╝")

## -------- AKHIR BAGIAN MENU -------- ##

## -------- AWAL BAGIAN FITUR 1 -------- ##

def inputTanggal(msg): 
  formatTanggal = "%d/%m/%Y" 
  while True:
    try: 
      tanggalUser = input(msg)

      if not tanggalUser:
        tanggalUser = datetime.datetime.now().strftime(formatTanggal)

      objekDatetime = datetime.datetime.strptime(tanggalUser, formatTanggal)
      strDatetimeBersih = objekDatetime.strftime(formatTanggal)

      strTanggalUser, tanggalUsr = strDatetimeBersih, objekDatetime

      return strTanggalUser, tanggalUsr
    except ValueError:
      print(f"{BOLD}{RED}Input Tanggal Adalah DD/MM/YYYY, Contoh: 01/01/2025 untuk 1 Januari 2025{RESET}")

def simpanTugas(file, data, folder):
  fieldNames = list(data.keys())

  fileExist = os.path.exists(file)

  mode = 'a' if fileExist else 'w'

  os.makedirs(folder, exist_ok=True)

  try:
    with open(file, mode, newline='', encoding='utf-8') as csvfile:
      writer = csv.DictWriter(csvfile, fieldnames=fieldNames)
      if not fileExist:
        writer.writeheader()
        print(f"{GREEN}Membuat File Baru {file}{RESET}")
      writer.writerow(data)
  except Exception as e:
    print(f"{RED}{BOLD}Error: {e}{RESET}")

def buatID(tanggal, filePath):
  strTanggalID = tanggal.strftime("%d%m%y")
  strTanggalCek = tanggal.strftime("%d/%m/%Y")
  urutanID = 1

  if not os.path.exists(filePath):
    ID = f"{strTanggalID}{urutanID:02d}"
    return ID
  
  try:
    data = loadTugas(filePath)
    for tugas in data:
      if tugas['tanggal_pemberian'] == strTanggalCek:
        urutanID+=1

    ID = f"{strTanggalID}{urutanID:02d}"
    return ID
  
  except Exception as e:
    print(f"{RED}{BOLD}Error: {e}{RESET}")
    
def kondisiTugas(kondisi):
  if not kondisi:
    return "Belum Selesai"
  else:
    return "Selesai"

def tambahTugas():
  GARIS_PENUH = "═" * 60
  JUDUL = "TAMBAH TUGAS"
  print(GARIS_PENUH)
  print(f"{BCYAN}{BOLD}{JUDUL.center(60)}{RESET}")
  print(GARIS_PENUH)
  
  mataPelajaran = loadUser()['mata_pelajaran']
  mataPelajaran.append('Lainnya')
  print(f"{BCYAN}{BOLD}\n\nList Mata Pelajaran:{RESET}")
  for i in range(len(mataPelajaran)):
    print(f"{i+1}. {mataPelajaran[i]}")
  tanggalHariIni = datetime.datetime.now().strftime("%d/%m/%Y")
  while True:
    try:
      mataPelajaranInput = inputAngkaAman("Pilih Mata Pelajaran: ", True, len(mataPelajaran), 1) - 1
      mataPelajaranUser = mataPelajaran[mataPelajaranInput]
      strtanggalPemberianUser, tanggalPemberianUser = inputTanggal(f"Masukkan Tanggal Pemberian Tugas (DD/MM/YYYY, Default {tanggalHariIni}): ")
      deskripsiUser = inputString("Masukkan Deskripsi Tugas: ")
      tingkatKesulitanUser = inputAngkaAman("Masukkan Tingkat Kesulitan (1 (Sangat Mudah) s.d. 5 (Sangat Sulit) ): ", True, 5, 1)
      strtanggalDeadlineUser, tanggalDeadlineUser = inputTanggal(f"Masukkan Tanggal Batas Pengumpulan (DD/MM/YYYY, Default {tanggalHariIni}): ")
    
      folderFile = f'{tanggalPemberianUser.year}'
      namaFile = f'{tanggalPemberianUser.month:02d}_{tanggalPemberianUser.strftime("%Y")}.csv'

      filePath = os.path.join(folderFile, namaFile)

      dataTugas = {
        'id': buatID(tanggalPemberianUser, filePath),
        "mata_pelajaran": mataPelajaranUser,
        "tanggal_pemberian": strtanggalPemberianUser,
        "deskripsi": deskripsiUser,
        "tingkat_kesulitan": tingkatKesulitanUser,
        "tanggal_pengumpulan": strtanggalDeadlineUser,
        "level_prioritas": levelPrioritas(tanggalDeadlineUser, tingkatKesulitanUser),
        "kondisi_tugas": kondisiTugas(False)
      }

      simpanTugas(filePath, dataTugas, folderFile)

      print(f"\n\n{YELLOW}Menyimpan Data Tugas Terbaru!{RESET}")
      print(f"   ID                              : {BOLD}{dataTugas['id']}{RESET}")
      print(f"   Mata Pelajaran                  : {BOLD}{dataTugas['mata_pelajaran']}{RESET}")
      print(f"   Tanggal Pemberian               : {BOLD}{dataTugas['tanggal_pemberian']}{RESET}")
      print(f"   Deskripsi                       : {BOLD}{dataTugas['deskripsi']}{RESET}")
      print(f"   Tingkat Kesulitan               : {BOLD}{dataTugas['tingkat_kesulitan']}{RESET}")
      print(f"   Tanggal Pengumpulan Maksimal    : {BOLD}{dataTugas['tanggal_pengumpulan']}{RESET}")
      print(f"   Tingkat Prioritas               : {BOLD}{dataTugas['level_prioritas']}{RESET}")
      print(f"   Kondisi Tugas                   : {BOLD}{dataTugas['kondisi_tugas']}{RESET}")
    
      pause_and_continue()
      return 0
    except ValueError:
      print(f"{BOLD}{RED}Tolong Masukkan Angka!{RESET}")

## -------- AKHIR BAGIAN FITUR 1 -------- ##

## -------- AWAL BAGIAN FITUR 2 -------- ##

def inputTahunBulan(msg, jenis):
  hariIni = datetime.datetime.now()
  output = 0
  while True:
    try: 
      userInput = input(msg)
      if (not userInput) and jenis == 'bulan':
        output = hariIni.month
        return output
      elif (not userInput) and jenis == 'tahun':
        output = hariIni.year
        return output
      
      angkaInput = int(userInput)
      
      if not (0 < angkaInput <= 12) and jenis == 'bulan':
        raise ValueError
      elif (not len(userInput) == 4) and jenis == 'tahun':
        raise ValueError
      
      return angkaInput
    except ValueError:
      if jenis == 'bulan':
        print(f"{BOLD}{RED}Input berformat 2 digit: 01 untuk Januari{RESET}")
      elif jenis == 'year':
        print(f"{BOLD}{RED}Input berformat 4 digit{RESET}")

def pointTugasSelesai(tanggalDeadline):
  data=loadUser()
  objTanggalHariIni = datetime.datetime.now().strftime("%d/%m/%Y")
  objTanggalDeadline = datetime.datetime.strptime(tanggalDeadline, "%d/%m/%Y")

  tahunSisa = objTanggalDeadline.year - objTanggalHariIni.year
  bulanSisa = objTanggalDeadline.month - objTanggalHariIni.month
  hariSisa = objTanggalDeadline.day - objTanggalHariIni.day

  hariSisaTotal = tahunSisa * 365 + bulanSisa * 30 + hariSisa
   
  if hariSisaTotal <= 1:
    data['point'] += 1
  elif hariSisaTotal <= 2:
    data['point'] += 2
  elif hariSisaTotal <= 3:
    data['point'] += 3
  else:
    data['point'] += 4

  dataNew = {
    'nama_lengkap': data['nama_lengkap'],
    'nama_panggilan': data['nama_panggilan'],
    'kelas': data['kelas'],
    'mata_pelajaran': data['mata_pelajaran'],
    'point': data['point'],
  }

  updateUser(dataNew)

def updateCSVbyID(filePath, ID):
  dataDiperbarui = []
  tugasDitemukan = False

  try:
    with open(filePath,'r', newline ='', encoding ='utf-8') as infile:
      reader = csv.DictReader(infile)
      fieldnames = reader.fieldnames

      for row in reader:
        if row['id'] == ID:
          row['kondisi_tugas'] = "Selesai"
          row['level_prioritas'] = "-"
          tugasDitemukan = True
          print(f"{BCYAN}{BOLD}Tugas ID: {ID} berhasil ditandai selesai.")
          print(f"Mata Pelajaran: {row['mata_pelajaran']}")
          print(f"Deskripsi     : {row['deskripsi']}{RESET}")
          pointTugasSelesai(row['tanggal_pengumpulan'])
          dataUser = loadUser()
          print(f"Pointmu Bertambah Menjadi {dataUser['point']}")
        dataDiperbarui.append(row)

      if not tugasDitemukan:
        print(f"{RED}Tugas dengan ID: {ID} tidak ditemukan.{RESET}")
        return
      
    with open(filePath, 'w', newline='', encoding='utf-8') as outfile:
      writer = csv.DictWriter(outfile, fieldnames)

      writer.writeheader()
      writer.writerows(dataDiperbarui)

  except Exception as e:
    print(f"{RED}{BOLD}Error: {e}{RESET}")

def selesaiTugas():
  GARIS_PENUH = "═" * 60
  JUDUL = "MENYELESAIKAN TUGAS"
  print(GARIS_PENUH)
  print(f"{BCYAN}{BOLD}{JUDUL.center(60)}{RESET}")
  print(GARIS_PENUH)

  hariIni = datetime.datetime.now()

  bulan = inputTahunBulan(f'Masukkan Bulan saat Tugasmu Diberikan (Default : {hariIni.month:02d}): ', 'bulan')
  tahun = inputTahunBulan(f'Masukkan Tahun saat Tugasmu Diberikan (Default : {hariIni.year:02d}): ', 'tahun')

  namaFile = f"{bulan:02d}_{tahun}.csv"
  folder = f"{tahun}"

  filePath = os.path.join(folder, namaFile)

  if (not os.path.exists(filePath)) or (os.path.getsize(filePath) == 0):
    print(f"{BCYAN}{BOLD}Tidak ada tugas pada bulan {bulan}, tahun {tahun}!{RESET}")
    pause_and_continue()
    return 0

  data = loadTugas(filePath)
  dataBelumSelesai = []
  for row in data:
    if(row['kondisi_tugas'] == 'Belum Selesai'):
      dataBelumSelesai.append(row)

  if not dataBelumSelesai:
    print(f"{BCYAN}{BOLD}Semua tugas pada bulan {bulan}, tahun {tahun} telah diselesaikan semua!{RESET}")
    pause_and_continue()
    return 0
  
  loadTugasTabel(filePath, 'kt', 'Belum Selesai')

  idUser = str(input('Masukkan ID (8 Digit): '))
  
  print("\n\n")
  print(GARIS_PENUH)
  updateCSVbyID(filePath, idUser)
  pause_and_continue()

## -------- AKHIR BAGIAN FITUR 2 -------- ##

## -------- AWAL BAGIAN FITUR 3 -------- ##
def inputKriteria():
  while True:
    try:
      inputUser = input("Masukkan Angka Kriteria Tabel yang Ingin Ditampilkan (Default: Semua Tugas): ")
      if not inputUser:
        return 6
    
      if not(0 < int(inputUser) <= 6):
        raise Exception(f"Masukkan Angka Di antara 1 s.d. 6")
    
      return int(inputUser)
  
    except Exception as e:
      print(f"{RED}{BOLD}{e}{RESET}")

def kriteriaMP():
  dataMataPelajaran = loadUser()['mata_pelajaran']
  dataMataPelajaran.append('Lainnya')

  print(f'\n{BCYAN}{BOLD}List Mata Pelajaran:{RESET}')
  for i in range(len(dataMataPelajaran)):
    print(f"{i+1}. {dataMataPelajaran[i]}")
  
  syaratInput = inputAngkaAman('Pilih Mata Pelajaran yang Ingin Ditampilkan: ', True, len(dataMataPelajaran), 1)
  syaratUser = dataMataPelajaran[syaratInput-1]

  return syaratUser

def kriteriaLP():
  listLevelPrioritas = ['Rendah', "Sedang", "Tinggi", "Sangat Kritis"]

  print(f'\n{BCYAN}{BOLD}List Tingkat Prioritas:{RESET}')
  for i in range(len(listLevelPrioritas)):
    print(f"{i+1}. {listLevelPrioritas[i]}")
  
  syaratInput = inputAngkaAman('Pilih Tingkat Prioritas yang Ingin Ditampilkan: ', True, len(listLevelPrioritas), 1)
  syaratUser = listLevelPrioritas[syaratInput-1]

  return syaratUser

def kriteriaKT():
  listKondisiTugas = ['Belum Selesai', "Selesai"]

  print(f'\n{BCYAN}{BOLD}List Status Tugas:{RESET}')
  for i in range(len(listKondisiTugas)):
    print(f"{i+1}. {listKondisiTugas[i]}")
  
  syaratInput = inputAngkaAman('Pilih Status Tugas yang Ingin Ditampilkan: ', True, len(listKondisiTugas), 1)
  syaratUser = listKondisiTugas[syaratInput-1]

  return syaratUser

def daftarTugas():
  GARIS_PENUH = "═" * 60
  JUDUL = "MENAMPILKAN TUGAS"
  print(GARIS_PENUH)
  print(f"{BCYAN}{BOLD}{JUDUL.center(60)}{RESET}")
  print(GARIS_PENUH)

  hariIni = datetime.datetime.now()

  bulan = inputTahunBulan(f'Masukkan Bulan untuk List Tugas (Default : {hariIni.month:02d}): ', 'bulan')
  tahun = inputTahunBulan(f'Masukkan Tahun untuk List Tugas (Default : {hariIni.year:02d}): ', 'tahun')

  namaFile = f"{bulan:02d}_{tahun}.csv"
  folder = f"{tahun}"

  filePath = os.path.join(folder, namaFile)

  if not os.path.exists(filePath):
    print(f"{BOLD}{BCYAN}Tidak ada tugas pada bulan {bulan}, tahun {tahun}!{RESET}")
    pause_and_continue()
    return 0
  
  if os.path.getsize(filePath) == 0:
    print(f"{BOLD}{BCYAN}Tidak ada tugas pada bulan {bulan}, tahun {tahun}!{RESET}")
    pause_and_continue()
    return 0

  print(f"{BCYAN}{BOLD}\nPilih Tabel yang Ditampilkan Berdasarkan:{RESET}\n" \
  "1. Mata Pelajaran\n" \
  "2. Tanggal Pemberian Tugas\n" \
  "3. Tanggal Maksimal Pengumpulan Tugas\n" \
  "4. Tingkat Prioritas\n" \
  "5. Kondisi Tugas\n" \
  "6. Semua Tugas")

  kriteriaInput = inputKriteria()
  kriteria = {
    1: 'mp',
    2: 'tpem',
    3: 'tpeng',
    4: 'lp',
    5: 'kt',
    6: None
  }
  kriteriaUser = kriteria[kriteriaInput]
  loadTugasUser = loadTugas(filePath)
  syaratDipenuhi = []

  if kriteriaUser == 'mp':
    syarat = kriteriaMP()
  elif kriteriaUser == 'tpem':
    syarat, x = inputTanggal(f'Masukkan Tanggal Pemberian Tugas (DD/MM/YYYY) Default {hariIni.strftime('%d/%m/%Y')}: ')
  elif kriteriaUser == 'tpeng':
    syarat, x = inputTanggal(f'Masukkan Tanggal Maksimal Pengumpulan Tugas (DD/MM/YYYY) Default {hariIni.strftime('%d/%m/%Y')}: ')
  elif kriteriaUser == 'lp':
    syarat = kriteriaLP()
  elif kriteriaUser == 'kt':
    syarat = kriteriaKT()
  elif kriteriaUser == None:
    syarat = None

  dictTipeKondisi = {
    'mp': "mata_pelajaran", 
    'tpem': 'tanggal_pemberian', 
    'tpeng': 'tanggal_pengumpulan', 
    'lp': 'level_prioritas',
    'kt': 'kondisi_tugas'
  }

  for data in loadTugasUser:
    if kriteriaUser != None:
      if data[dictTipeKondisi[kriteriaUser]] == syarat:
        syaratDipenuhi.append(data)

  if not syaratDipenuhi and (kriteriaUser != None):
    print(f"{BCYAN}{BOLD}Tidak ada tugas yang memenuhi syarat: {syarat}, kriteria: {dictTipeKondisi[kriteriaUser]}{RESET}")
    pause_and_continue()
    return 0
  
  print("\n\n")
  updateCSVPrioritas(filePath)
  loadTugasTabel(filePath, kriteriaUser, syarat)

  pause_and_continue()
  return 0

## -------- AKHIR BAGIAN FITUR 3 -------- ##

## -------- AWAL BAGIAN FITUR 4 -------- ##
def stopwatch(seconds):
  while seconds > 0:
    menit = seconds // 60
    detik = seconds % 60
    waktu = f"{menit:02d}:{detik:02d}"

    print(f"Waktu Tersisa: {waktu}", end="\r", flush=True)

    time.sleep(1)
    seconds -= 1
  
  print("Waktu Tersisa: 00:00")

def pomodoroWaktu(lamaJam):
  menit = lamaJam * 60
  print(f"{BOLD}{BYELLOW}Mode Belajar Dimulai{RESET}")

  while menit > 0:
    print(f"{BOLD}Belajar 25 Menit Dimulai{RESET}")
    stopwatch(25*60)
    print(f"{BOLD}Belajar 25 Menit Selesai{RESET}")
    menit -= 25
    print(f"{BOLD}Istirahat 5 Menit Dimulai{RESET}")
    stopwatch(5*60)
    print(f"{BOLD}Istirahat 5 Menit Selesai{RESET}")
    menit -= 5

  print(f"{BOLD}{BYELLOW}Mode Belajar Selesai!{RESET}")
  updateLastStudyDate()

def sesiBelajar():
  GARIS_PENUH = "═" * 60
  JUDUL = "SESI BELAJAR"
  print(GARIS_PENUH)
  print(f"{BCYAN}{BOLD}{JUDUL.center(60)}{RESET}")
  print(GARIS_PENUH)

  print("\n")
  jumlahMataPelajaran = inputAngkaAman("Jumlah Mata Pelajaran yang Ingin Kamu Pelajari (1 s.d. 3): ", True, 3, 1)

  mataPelajaran = loadUser()['mata_pelajaran']
  mataPelajaran.append('Lainnya')
  print(f"{BCYAN}{BOLD}\n\nList Mata Pelajaran:{RESET}")
  for i in range(len(mataPelajaran)):
    print(f"{i+1}. {mataPelajaran[i]}")
  
  mataPelajaranInput = []

  for i in range(jumlahMataPelajaran):
    mp = inputAngkaAman(f"Pilih Mata Pelajaran ke-{i+1}: ", True, len(mataPelajaran), 1)
    mataPelajaranInput.append(mp)

  mataPelajaranUser = [mataPelajaran[i-1] for i in mataPelajaranInput]
  
  print(f"\n{BOLD}{BCYAN}List Pelajaran yang Dipilih:{RESET}")

  for i in range(len(mataPelajaranUser)):
    print(f"Mata Pelajaran {i+1}: {mataPelajaranUser[i]}")

  print(f"\n{BCYAN}{BOLD}Lama Jam Belajar:{RESET}")
  print("1. 1 Jam\n" \
  "2. 2 Jam\n" \
  "3. 3 Jam\n" \
  "4. 4 Jam")

  lamaJamInput = inputAngkaAman('Pilih Lama Jam Kamu Belajar (1 s.d. 4): ', True, 4, 1)
  pause_and_continue("Apakah Kamu Siap Belajar? Tekan Enter Jika Kamu Siap")
  pomodoroWaktu(lamaJamInput)

  pause_and_continue()
## -------- AKHIR BAGIAN FITUR 4 -------- ##

## -------- AWAL BAGIAN FITUR 5 -------- ##
def editAkun():
  dataLama = loadUser()
  keyData = ["Nama Lengkap", 'Nama Panggilan', "Kelas", "Mata Pelajaran"]

  print(f"{BCYAN}{BOLD}\nPilih Data yang Ingin Anda Edit:{RESET}")
  for i in range(len(keyData)):
    print(f"{i+1}. {keyData[i]}")
  
  keyInput = inputAngkaAman('Masukkan Angka Data yang Ingin Anda Edit: ', True, len(keyData), 1)

  if keyInput == 1:
    namaLengkapBaru = inputString(f"\nMasukkan Nama Lengkap Baru (Sebelumnya: {dataLama['nama_lengkap']}): ")
    dataBaru = {
      'nama_lengkap': namaLengkapBaru,
      'nama_panggilan': dataLama['nama_panggilan'],
      'kelas': dataLama['kelas'],
      'mata_pelajaran': dataLama['mata_pelajaran'],
      'point': dataLama['point'],
    }

  elif keyInput == 2:
    namaPanggilanBaru = inputString(f"\nMasukkan Nama Panggilan Baru (Sebelumnya: {dataLama['nama_panggilan']}): ")
    dataBaru = {
      'nama_lengkap': dataLama['nama_lengkap'],
      'nama_panggilan': namaPanggilanBaru,
      'kelas': dataLama['kelas'],
      'mata_pelajaran': dataLama['mata_pelajaran'],
      'point': dataLama['point'],
    }

  elif keyInput == 3:
    kelasBaru = inputAngkaAman(f"\nMasukkan Kelas Baru (Sebelumnya: {dataLama['kelas']}): ", True)
    dataBaru = {
      'nama_lengkap': dataLama['nama_lengkap'],
      'nama_panggilan': dataLama['nama_panggilan'],
      'kelas': kelasBaru,
      'mata_pelajaran': dataLama['mata_pelajaran'],
      'point': dataLama['point'],
    }

  elif keyInput == 4:
    print("\nMata Pelajaran Sebelumnya:")
    for i in range(len(dataLama['mata_pelajaran'])):
      print(f"{i+1}. {dataLama['mata_pelajaran'][i]}")
    mataPelajaranInput = inputString(f"Masukkan Mata Pelajaran Baru, {RED}{BOLD}semua mata pelajaran lama akan hilang{RESET} (Pisahkan menggunakan koma ','): ")
    mataPelajaranKotor = mataPelajaranInput.split(',')
    mataPelajaranBaru = []
    for mapel in mataPelajaranKotor:
      mapelBersih = mapel.strip()
      if mapelBersih:
        mataPelajaranBaru.append(mapelBersih)

    dataBaru = {
      'nama_lengkap': dataLama['nama_lengkap'],
      'nama_panggilan': dataLama['nama_panggilan'],
      'kelas': dataLama['kelas'],
      'mata_pelajaran': mataPelajaranBaru,
      'point': dataLama['point'],
    }
    
  updateUser(dataBaru)
def lihatAkun():
  dataUser = loadUser()

  GARIS_PENUH = "═" * 60
  JUDUL = "AKUN SAYA"
  print(GARIS_PENUH)
  print(f"{BCYAN}{BOLD}{JUDUL.center(60)}{RESET}")
  print(GARIS_PENUH)
  
  print(f"  Nama Lengkap  : {dataUser['nama_lengkap']}")
  print(f"  Nama Panggilan: {dataUser['nama_panggilan']}")
  print(f"  Kelas         : {dataUser['kelas']}")
  print(f"  Mata Pelajaran:")
  for i in range(len(dataUser['mata_pelajaran'])):
    print(f"    {i+1}. {dataUser['mata_pelajaran'][i]}")
  print(f"  Poin          : {dataUser['point']}")

  while True:
    editInput = inputString("Apakah Kamu Mau Mengubah Data Diri? (y/n): ")
    if editInput == 'y':
      editAkun()
      break
    elif editInput == 'n':
      break
    print(f"{RED}{BOLD}Masukkan y atau n!{RESET}")

  pause_and_continue()

## -------- AKHIR BAGIAN FITUR 5 -------- ##

## -------- AWAL BAGIAN MENU -------- ##

def main():
  clearScreen()
  while True:
    if not os.path.exists(CONFIG_JSON_USER):
      try:
        startNew()
      except ValueError:
        print('Masukkan Angka dengan Benar!')

    elif not os.path.getsize(CONFIG_JSON_USER) > 0:
      try:
        startNew()
      except ValueError:
        print('Masukkan Angka dengan Benar!')
    
    dataUser = loadUser()
    startOld()
    teksFitur = "1. Tambah Tugas\n" \
    "2. Tugas Selesai\n" \
    "3. Daftar Tugas\n" \
    "4. Sesi Belajar\n" \
    "5. Lihat Akun\n"\
    "6. Keluar"

    
    print(teksFitur)
    fiturUser = inputAngkaAman(f"{BCYAN}Masukkan Fitur yang Ingin {dataUser['nama_panggilan']} Gunakan: {RESET}", True, 6, 1)

    if fiturUser == 1:
      clearScreen()
      tambahTugas()
      clearScreen()
    elif fiturUser == 2:
      clearScreen()
      selesaiTugas()
      clearScreen()
    elif fiturUser == 3:
      clearScreen()
      daftarTugas()
      clearScreen()
    elif fiturUser == 4:
      clearScreen()
      sesiBelajar()
      clearScreen()
    elif fiturUser == 5:
      clearScreen()
      lihatAkun()
      clearScreen()
    elif fiturUser == 6:
      clearScreen()
      pesanEndApp()
      break
    else:
      print(f"{BOLD}{RED}Masukkan Nilai Input dengan Benar!{RESET}")
    

if __name__ == "__main__":
  main()